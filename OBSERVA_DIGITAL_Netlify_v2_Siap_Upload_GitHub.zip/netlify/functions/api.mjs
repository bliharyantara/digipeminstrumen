import {getStore} from '@netlify/blobs';
import {createHash,createHmac,randomUUID,timingSafeEqual} from 'node:crypto';
import {ITEMS,DIMENSIONS,validateObservation,aggregate,sessionKey} from '../../lib/core.mjs';
import {makePdf} from '../../lib/pdf.mjs';

const noStore={'Cache-Control':'no-store, private','X-Content-Type-Options':'nosniff'};
function json(value,status=200,extra={}){return new Response(JSON.stringify(value),{status,headers:{...noStore,'Content-Type':'application/json; charset=utf-8',...extra}});}
function fail(msg,status=400){return json({ok:false,error:msg},status);}
function secureCompare(a,b){const x=Buffer.from(String(a||'')),y=Buffer.from(String(b||''));return x.length===y.length && timingSafeEqual(x,y);}
const digest=s=>createHash('sha256').update(s).digest('hex');
function configurationReady(){return Boolean(process.env.ADMIN_PASSWORD&&process.env.OBSERVER_ACCESS_CODE&&process.env.SESSION_SECRET&&process.env.SESSION_SECRET.length>=32);}
function sign(v){return createHmac('sha256',process.env.SESSION_SECRET).update(v).digest('base64url');}
function makeCookie(){const exp=Date.now()+2*60*60*1000;const payload=Buffer.from(JSON.stringify({exp,nonce:randomUUID(),pwd:digest(process.env.ADMIN_PASSWORD)})).toString('base64url');return `obs_admin=${payload}.${sign(payload)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=7200`;}
function isAdmin(request){if(!configurationReady())return false;const cookie=(request.headers.get('cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('obs_admin='));if(!cookie)return false;const token=cookie.split('=')[1]||'';const [p,s]=token.split('.');if(!p||!s||!secureCompare(sign(p),s))return false;try{const data=JSON.parse(Buffer.from(p,'base64url').toString());return data.exp>Date.now()&&data.pwd===digest(process.env.ADMIN_PASSWORD);}catch{return false;}}
function sameOrigin(req){const origin=req.headers.get('origin');if(!origin)return true;try{return new URL(origin).origin===new URL(req.url).origin;}catch{return false;}}
function codeCheck(code){return secureCompare(code,process.env.OBSERVER_ACCESS_CODE||'not-configured');}
function safeName(s){return String(s||'laporan').normalize('NFKD').replace(/[^\w\- ]/g,'').trim().replace(/\s+/g,'-').slice(0,55)||'laporan';}
async function loadRecords(store){const keys=[];for await(const page of store.list({prefix:'obs/',paginate:true})){keys.push(...page.blobs.map(x=>x.key));if(keys.length>3000)throw new Error('Data lebih dari 3000 isian. Gunakan ekspor cadangan dan arsipkan data periode lama.');}
  const records=[];for(let i=0;i<keys.length;i+=24){const a=await Promise.all(keys.slice(i,i+24).map(async key=>{try{return await store.get(key,{type:'json'});}catch{return null;}}));records.push(...a.filter(Boolean));}
  return records;
}
async function attemptLogin(req,store,data){
  const ip=(req.headers.get('x-nf-client-connection-ip')||req.headers.get('x-forwarded-for')||'unknown').split(',')[0].trim();
  const key='logins/'+digest(ip+process.env.SESSION_SECRET).slice(0,32);
  const attempt=(await store.get(key,{type:'json'}))||{fails:0,until:0};
  if(attempt.until>Date.now())return fail('Terlalu banyak percobaan. Coba kembali dalam 15 menit.',429);
  if(!secureCompare(data.password,process.env.ADMIN_PASSWORD)){
    const fails=Number(attempt.fails||0)+1;
    await store.setJSON(key,{fails:fails>=5?0:fails,until:fails>=5?Date.now()+15*60*1000:0});
    return fail('Sandi admin tidak sesuai.',401);
  }
  await store.delete(key);
  return json({ok:true,role:'admin'},200,{'Set-Cookie':makeCookie()});
}
export default async function handler(request){
  try{
    const url=new URL(request.url),action=url.searchParams.get('action')||'config';
    if(request.method==='GET'&&action==='config')return json({ok:true,name:'OBSERVA DIGITAL',dimensions:DIMENSIONS,items:ITEMS.map(({id,dimension,title,hint})=>({id,dimension,title,hint})),ready:configurationReady()});
    if(!configurationReady())return fail('Konfigurasi server belum lengkap. Isi ADMIN_PASSWORD, OBSERVER_ACCESS_CODE, SESSION_SECRET pada Netlify.',503);
    if(['POST','PUT','DELETE'].includes(request.method)&&!sameOrigin(request))return fail('Asal permintaan tidak diizinkan.',403);
    const store=getStore('observa-digital-v2');
    if(action==='me'&&request.method==='GET')return json({ok:true,admin:isAdmin(request)});
    if(action==='login'&&request.method==='POST'){
      const data=await request.json();if(typeof data.password!=='string'||data.password.length>200)return fail('Format sandi tidak valid.');
      return attemptLogin(request,store,data);
    }
    if(action==='logout'&&request.method==='POST')return json({ok:true},200,{'Set-Cookie':'obs_admin=; Max-Age=0; Path=/; HttpOnly; Secure; SameSite=Strict'});
    if(action==='submit'&&request.method==='POST'){
      const raw=await request.text();if(raw.length>26000)return fail('Formulir melebihi batas ukuran.',413);
      const data=JSON.parse(raw);if(!codeCheck(data.observerCode))return fail('Kode akses observer tidak sesuai.',403);
      const r=validateObservation(data);
      const identity=[sessionKey(r),r.observerName.trim().toLocaleLowerCase('id-ID'),r.observerRole].join('|');
      const key='obs/'+digest(identity);
      const id='OBS-'+randomUUID().split('-')[0].toUpperCase();
      const record={...r,id,createdAt:new Date().toISOString(),version:2};
      const {modified}=await store.setJSON(key,record,{onlyIfNew:true});
      if(!modified)return fail('Observer dengan peran dan nama yang sama sudah mengisi sesi ini. Hubungi admin untuk koreksi.',409);
      return json({ok:true,id,message:'Observasi tersimpan.'},201);
    }
    if(!isAdmin(request))return fail('Akses hanya untuk admin. Silakan login.',401);
    if(action==='report'&&request.method==='GET'){
      const records=await loadRecords(store);return json({ok:true,report:aggregate(records)});
    }
    if(action==='pdf'&&request.method==='GET'){
      const records=await loadRecords(store);const report=aggregate(records);
      const teacherKey=url.searchParams.get('teacher')||null;
      if(!records.length)return fail('Belum ada data observasi untuk dibuatkan PDF.',404);
      const t=teacherKey?report.teachers.find(x=>x.key===teacherKey):null;
      if(teacherKey&&!t)return fail('Data guru tidak ditemukan.',404);
      const bytes=await makePdf(report,teacherKey);
      const filename=`OBSERVA-DIGITAL-${safeName(t?t.teacher:'REKAP-SEMUA')}.pdf`;
      return new Response(bytes,{status:200,headers:{...noStore,'Content-Type':'application/pdf','Content-Disposition':`inline; filename="${filename}"`}});
    }
    if(action==='backup'&&request.method==='GET'){
      const records=await loadRecords(store);return json({ok:true,exportedAt:new Date().toISOString(),records},200,{'Content-Disposition':`attachment; filename="OBSERVA-Backup-${new Date().toISOString().slice(0,10)}.json"`});
    }
    if(action==='delete'&&request.method==='POST'){
      const data=await request.json();const id=String(data.id||'');if(!/^OBS-[0-9A-F]{8}$/.test(id))return fail('ID observasi tidak valid.');
      const records=await loadRecords(store);const r=records.find(x=>x.id===id);if(!r)return fail('Observasi tidak ditemukan.',404);
      const key='obs/'+digest([sessionKey(r),r.observerName.trim().toLocaleLowerCase('id-ID'),r.observerRole].join('|'));
      await store.delete(key);return json({ok:true,message:'Observasi dihapus.'});
    }
    return fail('Endpoint tidak tersedia.',404);
  }catch(err){
    console.error('OBSERVA API:',err);
    if(err instanceof SyntaxError)return fail('Format data JSON tidak valid.',400);
    if(/wajib|tidak valid|maksimal|minimal|Skor|Catatan|Lengkapi|indikator|terobservasi|guru tidak ditemukan/i.test(err.message))return fail(err.message,400);
    return fail('Terjadi gangguan pada layanan penyimpanan. Coba lagi atau hubungi admin.',503);
  }
}
